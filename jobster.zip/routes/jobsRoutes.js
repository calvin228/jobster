const Jobs = require("../models/Jobs");
const requireLogin = require("../middleware/requireLogin");

module.exports = app => {
  //TODO : Protect All Routes in this file
  app.get("/jobs", (req, res) => {
    const jobs = Jobs.find({});
    jobs.then(jobs => {
      res.render("jobs", { user: req.user, jobdata: jobs });
    });
  });

  app.get("/jobs/:id", requireLogin, (req, res) => {
    const { id } = req.params;
    Jobs.findById(id)
      .populate("seeker", ["name", "email"])
      .populate("company", "name") // TODO : maybe this should be used on company
      .then(job => {
        res.render("jobDetail", { user: req.user, jobdata: job });
      });
  });

  app.post("/jobs/:id", (req, res) => {
    const { id } = req.params;
    Jobs.updateOne({ _id: id }, { $push: { seeker: req.user.id } }).then(() => {
      res.send("Job applied");
    });
  });
};
