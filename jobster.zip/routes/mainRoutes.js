const cloudinary = require('cloudinary');

module.exports = (app, upload) => {
  app.get("/", (req, res) => {
    res.render("home", {user: req.user});
  });

  app.get("/about", (req, res) => {
    res.send("about");
  });

  app.get("/profile", (req,res) => {
    res.render("profile", {user: req.user});
  });

  

  
}
