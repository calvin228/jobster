const mongoose = require("mongoose");
const { Schema } = mongoose;

const JobSchema = new Schema({
  job_title: String,
  salary: Number,
  location: String,
  company: { type: Schema.Types.ObjectId, ref: "User" },
  job_type: String,
  description: String,
  requirements: String,
  // requirement: {
  //   min_age: Number,
  //   max_age: Number,
  //   experience: Number,
  //   education: String,
  //   skill: String,
  //   language: String
  // },
  seeker: [{ type: Schema.Types.ObjectId, ref: "User" }],
  posted_at: { type: Date, required: true, default: Date.now }
});

module.exports = mongoose.model("Job",JobSchema);
